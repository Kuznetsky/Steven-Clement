Instructions for installing Ada's browser extension scripts for Alma. Steve has modified these a little for cataloguing.

The scripts are here: G:\Fileplan\Bib_Services\Non-Clio_formats\Alma Enhancement Scripts

and are called:

> Alma Enhancer [version number] (this script works in all of Alma)
 
> Cataloguing Checks and Tools [version number] (this script works the Alma MD Editor only)



For Firefox

1. Go to URL address bar and search for about:addons.  Search for Greasemonkey and click Install. Restart Firefox and the browser should reload with a monkey face at the top right of the page.

2. Click on the drop-down menu next to the monkey face in Firefox, and click New User Script.

3. Type "Name" into the name box and "Space" into the namespace box, then click "OK."

4. Delete all the grey text in the new text box.

5. Copy and paste one of the scripts into the new text box. 
You�ll get a yellow alert regarding Scam warning. Type in the words as instructed by the alert and then paste in the script.
Remove the words you typed from the first line and make sure the script now starts at line 1.

6. Click Save and close the text box.

7. Repeat instructions from step two to add more scripts.


For Chrome


1. Go to https://chrome.google.com/webstore/search/tampermonkey?hl=en-US and add Tampermonkey by clicking Add to Chrome. Click Add extension.

2. Click on the binoculars in the top right of the Chrome window and click Add New Script.

3. Delete all the text in the new script.

4. Copy and paste one of the scripts into the new Tampermonkey text box.

5. Save it by clicking on the floppy disc icon at the top left of the text box.

6. Go to the web address "chrome://extensions/", then tick "Allow access to file URLs" next to Tampermonkey.

7. Repeat instructions from step two to add more scripts.



Thank you to Celeste for road testing / improving the instructions.



Alma Enhancer Features:

*Click the [+] to open things in simple popup - You can check items or records and also stay on your search results

*Scan In multiple items in at once -  Return Items and Patron Services new in v0.75

*MMSIDs displayed in search results

*Link to print label from search results

*MMSIDs on search results and "view record" page are links to Metadata Editor with holdings open.



Holdings Script Features:

Latest version from 1.0.1 includes: 
			*Minor bug fixes
			*Shortcuts improved -- Instantly responsive
			*Popup labelprinter -- To activate in Chrome put "chrome://extensions/" into the address bar,
						then tick "Allow access to file URLs" next to Tampermonkey

*Holdings  .......................................... Alt + z

 -Schools Holdings

 -PDU Holdings

 -WN.MUS (some)

 -WN.GEN + ZP Holdings

 -WN.NCC Holdings

 -ATL accession shortcut

*Print Shortcut ...................................... Alt + p