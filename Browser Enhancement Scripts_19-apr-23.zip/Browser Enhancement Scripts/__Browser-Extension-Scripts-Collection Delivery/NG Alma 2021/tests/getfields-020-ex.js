Alica
9781867510864

Life
9780473525095

9781775541622
Gang

record_title_row_0_In wondrous dimensions / by Adam Willetts.
record_mmsId_row_0

        var iFrame = document.getElementById("yardsNgWrapper").contentWindow.document.getElementById("yards_iframe");
        var bib = iFrame.contentWindow.getElementsByClassName("bibs")[1].textContent;
        console.log(bibs);


========
https://stackoverflow.com/questions/43996892/javascript-queryselectorall-get-multiple-values-from-multiple-inputs/43997007
"document.querySelectorAll() returns a (non-live) NodeList, not an array. Fortunately it is possible to call the array methods on pseudo-arrays:"

function getValues(selector) {
    var els = document.querySelectorAll(selector);
    return [].map.call(els, el => el.value);

=========


WORKS
FOR TESTING IN CONSOLE

 function getfields(field) {
        var iFrame = document.getElementById("yardsNgWrapper").contentWindow.document.getElementById("yards_iframe");
        var i;
        var gotfield;
        var target = "MarcEditorPresenter.textArea." + field;
        //var target = new RegExp("MarcEditorPresenter.textArea." + field);
        var targetids = "";
        var targetid = "";
        var val = "";

        targetids = iFrame.contentWindow.document.querySelectorAll(`div[id^="${target}"]`);
        targetid = [].slice.call(targetids).map(function(el) {
            return el.id;}).join(", ");

        console.log("The Ex Libris MARC field is: " + targetid);
        if (targetid.length === 1) {
                    //for (i = 0; i < targetid.length; i++) {
                    gotfield = iFrame.contentWindow.document.getElementById(targetid).getElementsByClassName("gwt-Label")[0].textContent;
            if (typeof subfield === "undefined") {
                //
            }
            else {
                if (gotfield.indexOf("‡" + subfield) !== -1) {
                    gotfield = gotfield.split("‡" + subfield + " ").pop(0).split(" ‡").shift();
                }
                else {
                    return;
                }
            }
            return gotfield;
        }
            if (targetid.length > 1) {
                var targetidArr = targetid.split(", ");
                for (i = 0; i < targetidArr.length; i++) {
                   // Trim the excess whitespace.
                    targetidArr[i] = targetidArr[i].replace(/^\s*/, "").replace(/\s*$/, "");
                   // process
                    console.log(targetidArr[i]);
                    gotfield = iFrame.contentWindow.document.getElementById(targetidArr[i]).getElementsByClassName("gwt-Label")[0].textContent;
                    console.log(gotfield);
          }
            if (typeof subfield === "undefined") {
                //
            }
            else {
                if (gotfield.indexOf("‡" + subfield) !== -1) {
                    gotfield = gotfield.split("‡" + subfield + " ").pop(0).split(" ‡").shift();
                }
                else {
                    return;
                }
            }

            return gotfield;
        }
        else {
            return "null";
        }
    }

    getfields("650", "a");

    ====================================================================================================
Redesign


     function getfields(field) {
        var iFrame = document.getElementById("yardsNgWrapper").contentWindow.document.getElementById("yards_iframe");
        var i;
        var gotfield;
        var target = "MarcEditorPresenter.textArea." + field;
        //var target = new RegExp("MarcEditorPresenter.textArea." + field);
        var targetids = "";
        var targetid = "";
        var val = "";

        targetids = iFrame.contentWindow.document.querySelectorAll(`div[id^="${target}"]`);
        targetid = [].slice.call(targetids).map(function(el) {
            return el.id;}).join(", ");

        console.log("The Ex Libris MARC field is: " + targetid);
            if (targetid.length > 1) {
                var targetidArr = targetid.split(", ");
                for(i = 0; i < targetidArr.length; i++) {
                   // Trim the excess whitespace.
                    targetidArr[i] = targetidArr[i].replace(/^\s*/, "").replace(/\s*$/, "");
                   // process
                    console.log(targetidArr[i]);
                    gotfield = iFrame.contentWindow.document.getElementById(targetidArr[i]).getElementsByClassName("gwt-Label")[0].textContent;
                    console.log(gotfield);
          }
            return gotfield;
        }
    }

    getfields("020");
    ==========


mr-2 text-label ng-star-inserted


navMmsId



    var allElements = document.querySelectorAll("*");
for ( var counter = 0; counter < allElements.length; counter++)
{
   allElements[counter].addEventListener('click',function(ele){

       alert("id is " + this.id );
       alert("class is " this.className);

    });
}
